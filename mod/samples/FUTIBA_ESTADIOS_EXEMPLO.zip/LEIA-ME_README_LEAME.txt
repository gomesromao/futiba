FUTIBA - ESTADIO DE EXEMPLO / SAMPLE STADIUM / ESTADIO DE EJEMPLO

PT: Este .zip ja pode ser importado no jogo: EDITOR > IMPORTAR ESTADIOS (PC: ponha o .zip na pasta "estadios" ao lado do jogo; Android: ESCOLHER ARQUIVO). A pasta camadas_layers_capas tem cada parte nas MEDIDAS EXATAS (em pixels): ceu, estadio, torcida e placas 920x482; torcida de costas 490x470; miniatura 50x34. A pasta rosa_pink_rosa mostra como a IA deve entregar (rosa-choque #FF00FF onde fica transparente).

EN: This .zip can already be imported in the game: EDITOR > IMPORT STADIUMS (PC: put the .zip in the "estadios" folder next to the game; Android: CHOOSE FILE). The camadas_layers_capas folder has each part in the EXACT SIZES (in pixels): sky, stadium, crowd and boards 920x482; crowd from behind 490x470; thumbnail 50x34. The rosa_pink_rosa folder shows how your AI should deliver it (hot pink #FF00FF where it becomes see-through).

ES: Este .zip ya se puede importar en el juego: EDITOR > IMPORTAR ESTADIOS (PC: pon el .zip en la carpeta "estadios" al lado del juego; Android: ELEGIR ARCHIVO). La carpeta camadas_layers_capas tiene cada parte en las MEDIDAS EXACTAS (en pixeles): cielo, estadio, hinchada y vallas 920x482; hinchada de espaldas 490x470; miniatura 50x34. La carpeta rosa_pink_rosa muestra como debe entregarlo tu IA (rosa fuerte #FF00FF donde queda transparente).
